package connectfour;

public enum Player {
    One, Two
}
